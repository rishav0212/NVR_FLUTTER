import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/utils/app_haptics.dart';
import '../../../../shared/widgets/shared_widgets.dart';
import '../bloc/auth_bloc.dart';

/// Presentation layer for password recovery.
///
/// Collects user email and dispatches recovery events to the AuthBloc.
/// Listens to Bloc state to provide transient UI feedback (snackbars, haptics, shakes).
class ForgotPasswordPage extends StatefulWidget {
  const ForgotPasswordPage({super.key});

  @override
  State<ForgotPasswordPage> createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
  final _formKey = GlobalKey<FormState>();
  final _shakeKey = GlobalKey<ShakeWidgetState>();
  final _emailController = TextEditingController();

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  /// Validates the form before dispatching the recovery event.
  void _submit() {
    FocusScope.of(context).unfocus();
    if (_formKey.currentState?.validate() ?? false) {
      AppHaptics.medium();
      context.read<AuthBloc>().add(
        ForgotPasswordRequested(_emailController.text.trim()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
          onPressed: () {
            AppHaptics.light();
            context.pop();
          },
        ),
      ),
      body: PageBackground(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: BlocConsumer<AuthBloc, AuthState>(
            listener: (context, state) {
              if (state is AuthError) {
                AppHaptics.error();
                _shakeKey.currentState?.shake();
              } else if (state is AuthActionSuccess) {
                AppHaptics.success();
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(state.message),
                    backgroundColor: Theme.of(
                      context,
                    ).extension<AppColorsExtension>()!.success,
                  ),
                );
                context.pop();
              }
            },
            builder: (context, state) {
              final isLoading = state is AuthLoading;
              final errorMessage = state is AuthError ? state.message : null;

              return SafeArea(
                child: CustomScrollView(
                  slivers: [
                    SliverFillRemaining(
                      hasScrollBody: false,
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: AppTheme.s24,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const SizedBox(height: AppTheme.s48),

                            AnimatedEntrance(
                              delay: const Duration(milliseconds: 100),
                              child: Container(
                                width: 48,
                                height: 48,
                                decoration: AppTheme.amberIconBox(
                                  context,
                                  radius: AppTheme.rMd,
                                ),
                                child: const Icon(
                                  Icons.lock_reset_outlined,
                                  color: AppTheme.amber,
                                  size: 24,
                                ),
                              ),
                            ),
                            const SizedBox(height: AppTheme.s24),

                            AnimatedEntrance(
                              delay: const Duration(milliseconds: 200),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Reset Password',
                                    style: Theme.of(
                                      context,
                                    ).textTheme.displaySmall,
                                  ),
                                  const SizedBox(height: AppTheme.s6),
                                  Text(
                                    "Enter your email and we'll send you instructions to reset your password.",
                                    style: Theme.of(
                                      context,
                                    ).textTheme.bodyMedium,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: AppTheme.s32),

                            AnimatedEntrance(
                              delay: const Duration(milliseconds: 300),
                              child: ShakeWidget(
                                key: _shakeKey,
                                child: Form(
                                  key: _formKey,
                                  child: AppTextField(
                                    label: 'Email',
                                    controller: _emailController,
                                    keyboardType: TextInputType.emailAddress,
                                    prefixIcon: Icons.mail_outline_rounded,
                                    textInputAction: TextInputAction.done,
                                    autofocus: true,
                                    onSubmitted: (_) => _submit(),
                                    validator: (v) {
                                      if (v == null || v.isEmpty)
                                        return 'Email is required';
                                      if (!v.contains('@'))
                                        return 'Enter a valid email';
                                      return null;
                                    },
                                  ),
                                ),
                              ),
                            ),

                            if (errorMessage != null) ...[
                              const SizedBox(height: AppTheme.s16),
                              AnimatedEntrance(
                                delay: Duration.zero,
                                child: ErrorBanner(message: errorMessage),
                              ),
                            ],

                            const Spacer(),
                            const SizedBox(height: AppTheme.s28),

                            AnimatedEntrance(
                              delay: const Duration(milliseconds: 400),
                              child: PrimaryButton(
                                label: 'Send Reset Link',
                                onPressed: _submit,
                                isLoading: isLoading,
                              ),
                            ),
                            const SizedBox(height: AppTheme.s32),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
